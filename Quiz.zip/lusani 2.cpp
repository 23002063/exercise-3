#include<iostream>
using namespace std;

int main(){
    int age;
cout<<"enter your age"<<endl;
std::cin>>age;
if(age>=18)
    std::cout<<"fit the description"<<endl;
else if(age<=25)
   std:: cout<<"fit the description"<<endl;
else
    std::cout<<"do not fit the description"<<endl;
int weight;
std::cout<<"enter your weight"<<endl;
std::cin>>weight;

  if(weight>= 70)
    std::cout<<"fit the description"<<endl;
  else if(weight<=80)
    std::cout<<"fit the description"<<endl;
  else
    std::cout<<"do not fit the description"<<endl;

    return 0;

}
